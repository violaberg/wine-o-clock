//function initMap() {
//  const loader = new google.maps.Marker({
//    position: { lat: 45.061724, lng: -0.887769 },
//    map: new google.maps.Map(document.getElementById("map"), {
//      center: { lat: 45.061724, lng: -0.887769 },
//      zoom: 14,
//    }),
//  });
//}
